Birthday Website — Final

1. Right-click this ZIP and choose "Extract All".
2. Open the extracted folder.
3. Double-click index.html to open the website in Chrome.
4. Page 2 uses your 7 uploaded photos (01.jpeg to 07.jpeg).
5. The photos are set to a smaller size with object-fit: contain so faces are not cropped.
6. If you add music, place a file named music.mp3 beside index.html.
